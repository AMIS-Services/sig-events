package nl.amis.ecommerce.status;

public enum OrderStatus {
    CREATED, SHIPPED, REJECTED
}
