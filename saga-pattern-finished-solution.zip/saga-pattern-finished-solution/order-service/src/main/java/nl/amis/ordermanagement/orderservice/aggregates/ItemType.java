package nl.amis.ordermanagement.orderservice.aggregates;

public enum ItemType {

    LAPTOP, HEADPHONE, SMARTPHONE
}
