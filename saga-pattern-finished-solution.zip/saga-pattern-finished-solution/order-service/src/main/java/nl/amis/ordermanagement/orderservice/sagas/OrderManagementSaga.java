package nl.amis.ordermanagement.orderservice.sagas;

import nl.amis.ecommerce.commands.CreateInvoiceCommand;
import nl.amis.ecommerce.commands.CreateShippingCommand;
import nl.amis.ecommerce.commands.UpdateOrderStatusCommand;
import nl.amis.ecommerce.events.*;
import nl.amis.ecommerce.status.OrderStatus;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.axonframework.modelling.saga.SagaEventHandler;
import org.axonframework.modelling.saga.SagaLifecycle;
import org.axonframework.modelling.saga.StartSaga;
import org.axonframework.spring.stereotype.Saga;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Logger;

@Saga
public class OrderManagementSaga {

    private final static Logger LOG = Logger.getLogger(OrderManagementSaga.class.getName());

    @Autowired
    private transient CommandGateway commandGateway;

    @StartSaga
    @SagaEventHandler(associationProperty = "orderId")
    public void handle(OrderCreatedEvent orderCreatedEvent){
        LOG.info("Saga invoked with orderid " + orderCreatedEvent.orderId);

        // Associate this Saga with the shipmentId
        String paymentId = UUID.randomUUID().toString();
        SagaLifecycle.associateWith("paymentId", paymentId);

        CompletableFuture<String> result = commandGateway.send(new CreateInvoiceCommand(paymentId, orderCreatedEvent.orderId, orderCreatedEvent.price));
    }

    @SagaEventHandler(associationProperty = "paymentId")
    public void handle(InvoiceCreatedEvent invoiceCreatedEvent){

        LOG.info("Saga continued");

        // Associate Saga with shipping
        String shippingId = UUID.randomUUID().toString();
        SagaLifecycle.associateWith("shipping", shippingId);

        // Send the create shipping command
        CompletableFuture<String> result = commandGateway.send(new CreateShippingCommand(shippingId, invoiceCreatedEvent.orderId, invoiceCreatedEvent.paymentId));
    }

    @SagaEventHandler(associationProperty = "paymentId")
    public void handle(InvoiceFailedEvent invoiceFailedEvent){
        LOG.info("Invoice failed");
        // Send the order update command
        CompletableFuture<String> result = commandGateway.send(new UpdateOrderStatusCommand(invoiceFailedEvent.orderId, OrderStatus.REJECTED));
    }

    @SagaEventHandler(associationProperty = "orderId")
    public void handle(OrderShippedEvent orderShippedEvent){
        CompletableFuture<String> result = commandGateway.send(new UpdateOrderStatusCommand(orderShippedEvent.orderId, OrderStatus.SHIPPED));
    }

    @SagaEventHandler(associationProperty = "orderId")
    public void handle(OrderUpdatedEvent orderUpdatedEvent){
        LOG.info("Saga ended");
        SagaLifecycle.end();
    }
}
