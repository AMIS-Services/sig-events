package nl.amis.paymentmanagement.paymentservice.aggregates;

public enum InvoiceStatus {

    PAID, PAYMENT_FAILED
}
