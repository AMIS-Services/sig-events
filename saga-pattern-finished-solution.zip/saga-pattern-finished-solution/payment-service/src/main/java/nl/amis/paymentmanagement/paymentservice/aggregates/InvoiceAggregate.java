package nl.amis.paymentmanagement.paymentservice.aggregates;

import nl.amis.ecommerce.commands.CreateInvoiceCommand;
import nl.amis.ecommerce.events.InvoiceCreatedEvent;
import nl.amis.ecommerce.events.InvoiceFailedEvent;
import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.modelling.command.AggregateIdentifier;
import org.axonframework.modelling.command.AggregateLifecycle;
import org.axonframework.spring.stereotype.Aggregate;

import java.math.BigDecimal;
import java.util.logging.Logger;

@Aggregate
public class InvoiceAggregate {

    private final static Logger LOG = Logger.getLogger(InvoiceAggregate.class.getName());

    @AggregateIdentifier
    private String paymentId;

    private String orderId;

    private BigDecimal price;

    private InvoiceStatus invoiceStatus;

    public InvoiceAggregate() {
    }

    @CommandHandler
    public InvoiceAggregate(CreateInvoiceCommand createInvoiceCommand){
        LOG.info("Handle command with order id " + createInvoiceCommand.orderId);
        if (createInvoiceCommand.price.compareTo(new BigDecimal(1000)) >= 0) {
            AggregateLifecycle.apply(new InvoiceFailedEvent(createInvoiceCommand.paymentId, createInvoiceCommand.orderId));
        } else {
            AggregateLifecycle.apply(new InvoiceCreatedEvent(createInvoiceCommand.paymentId, createInvoiceCommand.orderId, createInvoiceCommand.price));
        }
    }

    @EventSourcingHandler
    protected void on(InvoiceCreatedEvent invoiceCreatedEvent){
        LOG.info("Handle event with order id " + invoiceCreatedEvent.orderId);
        this.paymentId = invoiceCreatedEvent.paymentId;
        this.orderId = invoiceCreatedEvent.orderId;
        this.price = invoiceCreatedEvent.price;
        this.invoiceStatus = InvoiceStatus.PAID;
    }

    @EventSourcingHandler
    protected void on(InvoiceFailedEvent invoiceFailedEvent){
        LOG.info("Handle failed event with order id " + invoiceFailedEvent.orderId);
        this.paymentId = invoiceFailedEvent.paymentId;
        this.orderId = invoiceFailedEvent.orderId;
        this.invoiceStatus = InvoiceStatus.PAYMENT_FAILED;
    }
}
